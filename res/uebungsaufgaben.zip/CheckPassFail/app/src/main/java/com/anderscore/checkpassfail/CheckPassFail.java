package com.anderscore.checkpassfail;

/**
* Trying if-else statement.
*/
public class CheckPassFail {  // Save as "CheckPassFail.java"


    public void main(MainActivity out) {  // Program entry point
       //insert here...
    }
}