package com.anderscore.checkpassfail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView logOutput;

    private CheckPassFail checkPassFail = new CheckPassFail();

    /**
     * Print a whole line of text
     * @param text - Text to print
     */
    public void println(String text) {
        print(text + "\n");
    }

    /**
     *  Print text to the log Output without a new line
     * @param text Text to print
     */
    public void print(String text) {
        logOutput.setText(logOutput.getText() + text );
    }

    /**
     *  Clears all the text which has been written to the log Output
     */
    public void clearLog() {
        logOutput.setText("");
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logOutput = (TextView) findViewById(R.id.logOutput);
        clearLog();
        checkPassFail.main(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
