package com.anderscore.checkoddeven;

/**
* Trying if-else statement.
*/
public class CheckOddEven {  // Save as "CheckPassFail.java"


    public void main(MainActivity out) {  // Program entry point

    }
}