package com.anderscore.sumandaverage;

/**
 * Created by Max on 18.05.2016.
 */
public class SumAndAverage {
    public void main(MainActivity mainActivity) {
       
    }
}
